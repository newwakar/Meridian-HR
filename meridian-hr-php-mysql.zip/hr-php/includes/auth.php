<?php
require_once __DIR__ . '/../config.php';

if (session_status() === PHP_SESSION_NONE) {
    // Basic session hardening for a demo app. In production, also set
    // 'secure' => true (HTTPS only) and terminate/rotate sessions on privilege change.
    session_start([
        'cookie_httponly' => true,
        'cookie_samesite' => 'Lax',
    ]);
}

const MAX_LOGIN_ATTEMPTS = 5;
const LOCKOUT_MINUTES = 10;

/** Returns the logged-in user's session array, or null if not logged in. */
function current_user(): ?array {
    return $_SESSION['user'] ?? null;
}

function is_admin(): bool {
    $u = current_user();
    return $u && $u['role'] === 'admin';
}

function require_login(): void {
    if (!current_user()) {
        header('Location: login.php');
        exit;
    }
}

function require_admin(): void {
    require_login();
    if (!is_admin()) {
        http_response_code(403);
        die('Forbidden — this page is only available to admins.');
    }
}

/** CSRF token helpers — every state-changing form/AJAX call includes this token. */
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}
function csrf_field(): string {
    return '<input type="hidden" name="csrf" value="' . htmlspecialchars(csrf_token()) . '">';
}
function verify_csrf(?string $token): bool {
    return $token !== null && hash_equals($_SESSION['csrf'] ?? '', $token);
}

/**
 * Attempts to authenticate a username/password pair against the users
 * table. Applies a simple lockout after repeated failures to slow down
 * brute-force attempts.
 */
function attempt_login(string $username, string $password): array {
    $pdo = db();
    $stmt = $pdo->prepare("
        SELECT u.*, e.name AS emp_name, e.role_title, e.emp_code, e.color
        FROM users u
        LEFT JOIN employees e ON e.id = u.employee_id
        WHERE u.username = ?
        LIMIT 1
    ");
    $stmt->execute([$username]);
    $row = $stmt->fetch();

    if (!$row) {
        // Don't reveal whether the username exists.
        return ['ok' => false, 'error' => 'Invalid username or password.'];
    }

    if (!empty($row['locked_until']) && strtotime($row['locked_until']) > time()) {
        $mins = ceil((strtotime($row['locked_until']) - time()) / 60);
        return ['ok' => false, 'error' => "Account temporarily locked. Try again in {$mins} minute(s)."];
    }

    if (!password_verify($password, $row['password_hash'])) {
        $attempts = $row['failed_attempts'] + 1;
        if ($attempts >= MAX_LOGIN_ATTEMPTS) {
            $lockUntil = date('Y-m-d H:i:s', time() + LOCKOUT_MINUTES * 60);
            $pdo->prepare("UPDATE users SET failed_attempts = 0, locked_until = ? WHERE id = ?")
                ->execute([$lockUntil, $row['id']]);
            return ['ok' => false, 'error' => "Too many failed attempts. Account locked for " . LOCKOUT_MINUTES . " minutes."];
        }
        $pdo->prepare("UPDATE users SET failed_attempts = ? WHERE id = ?")->execute([$attempts, $row['id']]);
        return ['ok' => false, 'error' => 'Invalid username or password.'];
    }

    // Success — reset failure counter, rotate session id to prevent fixation.
    $pdo->prepare("UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE id = ?")->execute([$row['id']]);
    session_regenerate_id(true);

    $_SESSION['user'] = [
        'user_id'     => (int)$row['id'],
        'employee_id' => $row['employee_id'] !== null ? (int)$row['employee_id'] : null,
        'username'    => $row['username'],
        'role'        => $row['role'],
        'name'        => $row['role'] === 'admin' ? 'Meera Kapoor' : $row['emp_name'],
        'role_title'  => $row['role'] === 'admin' ? 'HR Manager' : $row['role_title'],
        'emp_code'    => $row['emp_code'],
        'color'       => $row['role'] === 'admin' ? '#16213E' : ($row['color'] ?: '#0F9D8C'),
    ];

    return ['ok' => true];
}

function do_logout(): void {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
}
