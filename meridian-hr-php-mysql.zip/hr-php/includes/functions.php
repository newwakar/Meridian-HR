<?php
require_once __DIR__ . '/../config.php';

const SHIFT_TYPES = [
    'morning' => ['label' => 'Morning', 'start' => '09:00:00', 'end' => '17:00:00'],
    'evening' => ['label' => 'Evening', 'start' => '14:00:00', 'end' => '22:00:00'],
    'night'   => ['label' => 'Night',   'start' => '22:00:00', 'end' => '06:00:00'],
];

function fmt_money(float $n): string {
    $sign = $n < 0 ? '-' : '';
    return $sign . '₹' . number_format(abs($n), 0);
}

function initials(string $name): string {
    $parts = preg_split('/\s+/', trim($name));
    $letters = array_map(function ($p) {
        return function_exists('mb_substr') ? mb_substr($p, 0, 1) : substr($p, 0, 1);
    }, array_slice($parts, 0, 2));
    $joined = implode('', $letters);
    return function_exists('mb_strtoupper') ? mb_strtoupper($joined) : strtoupper($joined);
}

function h(?string $s): string {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

function short_time(?string $t): string {
    if (!$t) return '—';
    return date('H:i', strtotime($t));
}

/** Haversine distance in meters between two lat/lng points. */
function distance_meters(float $lat1, float $lng1, float $lat2, float $lng2): float {
    $R = 6371000;
    $dLat = deg2rad($lat2 - $lat1);
    $dLng = deg2rad($lng2 - $lng1);
    $a = sin($dLat / 2) ** 2 + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLng / 2) ** 2;
    return $R * 2 * atan2(sqrt($a), sqrt(1 - $a));
}

/** Fetches all employees, optionally only active ones. */
function get_employees(bool $activeOnly = true): array {
    $pdo = db();
    $sql = "SELECT * FROM employees" . ($activeOnly ? " WHERE is_active = 1" : "") . " ORDER BY id";
    return $pdo->query($sql)->fetchAll();
}

function get_employee(int $id): ?array {
    $stmt = db()->prepare("SELECT * FROM employees WHERE id = ?");
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    return $row ?: null;
}

/** Sum of attendance-linked payroll_ledger entries for one employee. */
function attendance_adjustment(int $employeeId): float {
    $stmt = db()->prepare("SELECT COALESCE(SUM(amount),0) AS total FROM payroll_ledger WHERE employee_id = ?");
    $stmt->execute([$employeeId]);
    return (float)$stmt->fetch()['total'];
}

function net_pay(array $employee): float {
    return (float)$employee['base_salary'] + (float)$employee['bonus'] - (float)$employee['other_deduction'] + attendance_adjustment((int)$employee['id']);
}

/** Roster entry for one employee on one date, or null. */
function get_shift(int $employeeId, string $date): ?array {
    $stmt = db()->prepare("SELECT * FROM roster WHERE employee_id = ? AND shift_date = ?");
    $stmt->execute([$employeeId, $date]);
    return $stmt->fetch() ?: null;
}

/** All roster entries for a date range, keyed by "employeeId|date". */
function get_roster_range(string $startDate, string $endDate): array {
    $stmt = db()->prepare("SELECT * FROM roster WHERE shift_date BETWEEN ? AND ?");
    $stmt->execute([$startDate, $endDate]);
    $out = [];
    foreach ($stmt->fetchAll() as $row) {
        $out[$row['employee_id'] . '|' . $row['shift_date']] = $row;
    }
    return $out;
}

function upsert_shift(int $employeeId, string $date, string $shiftType): void {
    $t = SHIFT_TYPES[$shiftType];
    $stmt = db()->prepare("
        INSERT INTO roster (employee_id, shift_date, shift_type, shift_start, shift_end)
        VALUES (?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE shift_type = VALUES(shift_type), shift_start = VALUES(shift_start), shift_end = VALUES(shift_end)
    ");
    $stmt->execute([$employeeId, $date, $shiftType, $t['start'], $t['end']]);
}

function delete_shift(int $employeeId, string $date): void {
    db()->prepare("DELETE FROM roster WHERE employee_id = ? AND shift_date = ?")->execute([$employeeId, $date]);
}

function get_attendance(int $employeeId, string $date): ?array {
    $stmt = db()->prepare("SELECT * FROM attendance WHERE employee_id = ? AND attendance_date = ?");
    $stmt->execute([$employeeId, $date]);
    return $stmt->fetch() ?: null;
}

function push_notification(?int $employeeId, string $title, string $body, string $kind): void {
    db()->prepare("INSERT INTO notifications (employee_id, title, body, kind) VALUES (?, ?, ?, ?)")
        ->execute([$employeeId, $title, $body, $kind]);
}

/**
 * Core payroll/attendance rule:
 *   +50 credit for every scheduled shift the employee checked in for
 *   -50 debit for every scheduled shift that passed with no check-in
 * Only ever posts ONE ledger entry per employee per date (idempotent —
 * safe to re-run). Only evaluates shifts whose end time has already passed,
 * so an employee isn't marked absent before their shift is even over.
 */
function run_attendance_payroll_sync(?string $upToDate = null): array {
    $pdo = db();
    $upToDate = $upToDate ?: date('Y-m-d');
    $now = new DateTime();
    $summary = ['credited' => 0, 'debited' => 0];

    $shifts = $pdo->prepare("SELECT * FROM roster WHERE shift_date <= ?");
    $shifts->execute([$upToDate]);

    foreach ($shifts->fetchAll() as $shift) {
        $employeeId = (int)$shift['employee_id'];
        $date = $shift['shift_date'];

        // Skip if a ledger entry already exists for this employee/date (idempotent).
        $exists = $pdo->prepare("SELECT 1 FROM payroll_ledger WHERE employee_id = ? AND entry_date = ?");
        $exists->execute([$employeeId, $date]);
        if ($exists->fetch()) continue;

        // Only evaluate once the shift's end time has passed.
        $shiftEnd = new DateTime($date . ' ' . $shift['shift_end']);
        if ($shift['shift_type'] === 'night') $shiftEnd->modify('+1 day'); // night shift ends next morning
        if ($shiftEnd > $now) continue;

        $att = get_attendance($employeeId, $date);
        $emp = get_employee($employeeId);
        if (!$emp) continue;

        if ($att && $att['check_in']) {
            $pdo->prepare("INSERT INTO payroll_ledger (employee_id, entry_date, amount, reason) VALUES (?,?,?,?)")
                ->execute([$employeeId, $date, ATTENDANCE_CREDIT, 'Shift attended on ' . $date]);
            $pdo->prepare("UPDATE attendance SET status='present' WHERE employee_id=? AND attendance_date=?")
                ->execute([$employeeId, $date]);
            push_notification($employeeId, 'Attendance credit +' . fmt_money(ATTENDANCE_CREDIT),
                $emp['name'] . " attended the shift on $date.", 'pos');
            $summary['credited']++;
        } else {
            $pdo->prepare("INSERT INTO payroll_ledger (employee_id, entry_date, amount, reason) VALUES (?,?,?,?)")
                ->execute([$employeeId, $date, -ATTENDANCE_DEBIT, 'Missed scheduled shift on ' . $date]);
            if (!$att) {
                $pdo->prepare("INSERT INTO attendance (employee_id, attendance_date, status) VALUES (?,?, 'absent')")
                    ->execute([$employeeId, $date]);
            } else {
                $pdo->prepare("UPDATE attendance SET status='absent' WHERE employee_id=? AND attendance_date=?")
                    ->execute([$employeeId, $date]);
            }
            push_notification($employeeId, 'Attendance deduction -' . fmt_money(ATTENDANCE_DEBIT),
                $emp['name'] . " missed the scheduled shift on $date.", 'neg');
            $summary['debited']++;
        }
    }
    return $summary;
}

function get_notifications(?int $employeeId, int $limit = 15): array {
    $pdo = db();
    if ($employeeId === null) {
        $stmt = $pdo->prepare("SELECT * FROM notifications ORDER BY created_at DESC LIMIT ?");
        $stmt->bindValue(1, $limit, PDO::PARAM_INT);
    } else {
        $stmt = $pdo->prepare("SELECT * FROM notifications WHERE employee_id = ? ORDER BY created_at DESC LIMIT ?");
        $stmt->bindValue(1, $employeeId, PDO::PARAM_INT);
        $stmt->bindValue(2, $limit, PDO::PARAM_INT);
    }
    $stmt->execute();
    return $stmt->fetchAll();
}

/** Renders an attendance ring chart (present vs absent) as inline SVG. */
function ring_svg(int $present, int $absent, int $size = 90, int $stroke = 10, string $colorPresent = '#0F9D8C', string $colorAbsent = '#EEF0F5'): string {
    $total = max($present + $absent, 1);
    $r = ($size - $stroke) / 2;
    $c = $size / 2;
    $circ = 2 * M_PI * $r;
    $presentLen = $circ * ($present / $total);
    return sprintf(
        '<svg width="%1$d" height="%1$d" viewBox="0 0 %1$d %1$d">
            <circle cx="%2$s" cy="%2$s" r="%3$s" fill="none" stroke="%4$s" stroke-width="%5$d"/>
            <circle cx="%2$s" cy="%2$s" r="%3$s" fill="none" stroke="%6$s" stroke-width="%5$d"
              stroke-dasharray="%7$s %8$s" stroke-linecap="round" transform="rotate(-90 %2$s %2$s)"/>
        </svg>',
        $size, $c, $r, $colorAbsent, $stroke, $colorPresent, $presentLen, $circ - $presentLen
    );
}

function start_of_week(string $date): string {
    $d = new DateTime($date);
    $dow = (int)$d->format('N'); // 1 (Mon) .. 7 (Sun)
    $d->modify('-' . ($dow - 1) . ' days');
    return $d->format('Y-m-d');
}
