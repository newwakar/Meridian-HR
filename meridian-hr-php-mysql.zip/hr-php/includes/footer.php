      </div>
    </div>
  </div>
</div>

<div class="overlay" id="overlay"></div>
<div class="toast-wrap" id="toast-wrap"></div>

<script>window.CSRF_TOKEN = <?= json_encode(csrf_token()) ?>;</script>
<script src="assets/js/app.js"></script>
<?php if (!empty($pageScript)) echo "<script>$pageScript</script>"; ?>
</body>
</html>
