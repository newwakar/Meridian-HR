<?php
/**
 * Expects $pageKey, $pageTitle, $pageSub to be set by the including page.
 */
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/functions.php';
require_login();

$user = current_user();
$notifs = get_notifications($user['role'] === 'admin' ? null : $user['employee_id']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= h($pageTitle) ?> — Meridian HR</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div id="app">
  <div class="shell">
    <div class="sidebar" id="sidebar">
      <div class="brand"><span class="dot"></span> Meridian HR</div>

      <a class="nav-item <?= $pageKey === 'dashboard' ? 'active' : '' ?>" href="dashboard.php">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/></svg>
        Dashboard
      </a>
      <a class="nav-item <?= $pageKey === 'roster' ? 'active' : '' ?>" href="roster.php">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="17" rx="2"/><path d="M3 9h18M8 2v4M16 2v4"/></svg>
        Roster Planning
      </a>
      <a class="nav-item <?= $pageKey === 'attendance' ? 'active' : '' ?>" href="attendance.php">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg>
        Attendance
      </a>
      <a class="nav-item <?= $pageKey === 'payroll' ? 'active' : '' ?>" href="payroll.php">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="6" width="20" height="13" rx="2"/><circle cx="12" cy="12.5" r="3"/><path d="M6 6V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v1"/></svg>
        Payroll
      </a>
      <?php if ($user['role'] === 'admin'): ?>
      <a class="nav-item <?= $pageKey === 'employees' ? 'active' : '' ?>" href="employees.php">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>
        Employees
      </a>
      <?php endif; ?>

      <div class="spacer"></div>
      <div class="user-box">
        <div class="avatar" style="background:<?= h($user['color']) ?>"><?= h(initials($user['name'])) ?></div>
        <div class="who">
          <div class="n"><?= h($user['name']) ?></div>
          <div class="r"><?= $user['role'] === 'admin' ? 'Admin · ' . h($user['role_title']) : h($user['role_title']) ?></div>
        </div>
        <a class="logout-btn" href="logout.php" title="Sign out">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5M21 12H9"/></svg>
        </a>
      </div>
    </div>

    <div class="main">
      <div class="topbar">
        <div style="display:flex;align-items:center;gap:10px;">
          <button class="menu-btn" onclick="document.getElementById('sidebar').classList.toggle('open')">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M3 12h18M3 18h18"/></svg>
          </button>
          <div>
            <h1><?= h($pageTitle) ?></h1>
            <div class="page-sub"><?= h($pageSub) ?></div>
          </div>
        </div>
        <div class="topbar-right">
          <button class="bell-btn" onclick="document.getElementById('notif-panel').classList.toggle('open')">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
            <?php if (count($notifs) > 0): ?><span class="bell-dot"></span><?php endif; ?>
          </button>
        </div>
      </div>
      <div class="notif-panel" id="notif-panel">
        <?php if (empty($notifs)): ?>
          <div class="notif-item"><div class="d">No notifications yet.</div></div>
        <?php else: foreach ($notifs as $n): ?>
          <div class="notif-item <?= $n['kind'] ?>">
            <div class="t"><?= h($n['title']) ?></div>
            <div class="d"><?= h($n['body']) ?></div>
          </div>
        <?php endforeach; endif; ?>
      </div>
      <div class="content">
