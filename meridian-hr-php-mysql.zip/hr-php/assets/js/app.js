/* Shared helpers used by every page. Page-specific logic lives in an inline
   <script> block rendered by includes/footer.php via $pageScript. */

function toast(msg, kind) {
  const wrap = document.getElementById('toast-wrap');
  const el = document.createElement('div');
  el.className = 'toast ' + (kind || '');
  el.textContent = msg;
  wrap.appendChild(el);
  setTimeout(() => el.remove(), 3400);
}

function closeOverlay() {
  const overlay = document.getElementById('overlay');
  overlay.classList.remove('open');
  overlay.innerHTML = '';
}

function openOverlay(html) {
  const overlay = document.getElementById('overlay');
  overlay.innerHTML = html;
  overlay.classList.add('open');
}

/** POSTs form-encoded data (with CSRF token) to a JSON API endpoint. */
async function apiPost(url, data) {
  data.csrf = window.CSRF_TOKEN;
  const body = new URLSearchParams(data);
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body,
  });
  let json;
  try { json = await res.json(); } catch (e) { json = { ok: false, error: 'Unexpected server response.' }; }
  if (!res.ok && !json.error) json.error = 'Request failed (' + res.status + ').';
  return json;
}

// Close the notification dropdown when clicking outside it.
document.addEventListener('click', (e) => {
  const panel = document.getElementById('notif-panel');
  if (panel && !panel.contains(e.target) && !e.target.closest('.bell-btn')) {
    panel.classList.remove('open');
  }
});

/* ---- GPS + simulated face verification, shared by attendance.php ---- */
function haversineMeters(lat1, lon1, lat2, lon2) {
  const R = 6371000, toRad = x => x * Math.PI / 180;
  const dLat = toRad(lat2 - lat1), dLon = toRad(lon2 - lon1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function startFaceCapture(cb) {
  const box = document.getElementById('face-box');
  const placeholder = document.getElementById('face-placeholder');
  const badge = document.getElementById('face-badge');
  if (!box) { cb(true); return; }
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    placeholder.textContent = 'Camera unavailable in this browser — simulating face match.';
    setTimeout(() => cb(true), 900);
    return;
  }
  navigator.mediaDevices.getUserMedia({ video: true })
    .then(stream => {
      const video = document.createElement('video');
      video.autoplay = true; video.muted = true; video.playsInline = true;
      video.srcObject = stream;
      box.insertBefore(video, badge);
      placeholder.style.display = 'none';
      setTimeout(() => {
        badge.classList.add('show');
        badge.textContent = 'Verifying face…';
        setTimeout(() => {
          badge.textContent = 'Face verified ✓';
          stream.getTracks().forEach(t => t.stop());
          cb(true);
        }, 1300);
      }, 700);
    })
    .catch(() => {
      placeholder.textContent = 'Camera permission denied — simulating face match instead.';
      setTimeout(() => cb(true), 900);
    });
}
