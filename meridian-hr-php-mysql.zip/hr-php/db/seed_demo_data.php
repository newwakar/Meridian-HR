<?php
/**
 * Optional: populates two weeks of roster + attendance history so the app
 * has something to look at immediately after a fresh install.
 *
 *   php db/seed_passwords.php     (run this first)
 *   php db/seed_demo_data.php
 */
require __DIR__ . '/../config.php';
require __DIR__ . '/../includes/functions.php';

$pdo = db();
$employees = $pdo->query("SELECT id FROM employees ORDER BY id")->fetchAll();
$types = ['morning', 'morning', 'evening', 'morning', 'night', 'morning', 'evening', 'morning'];

$today = new DateTime('today');
$dow = (int)$today->format('N');
$thisWeekStart = (clone $today)->modify('-' . ($dow - 1) . ' days');
$lastWeekStart = (clone $thisWeekStart)->modify('-7 days');

function seed_week(PDO $pdo, DateTime $weekStart, array $employees, array $types, bool $includeAttendance, DateTime $now) {
    for ($d = 0; $d < 7; $d++) {
        $day = (clone $weekStart)->modify("+$d days");
        if ($day > $now) continue; // don't seed future days
        $ds = $day->format('Y-m-d');
        foreach ($employees as $i => $emp) {
            $empId = (int)$emp['id'];
            $off = (($d + $i) % 7 === 6) || ($d === 5 && $i % 3 === 0);
            if ($off) continue;

            $type = $types[$i % count($types)];
            $t = SHIFT_TYPES[$type];
            $pdo->prepare("INSERT IGNORE INTO roster (employee_id, shift_date, shift_type, shift_start, shift_end) VALUES (?,?,?,?,?)")
                ->execute([$empId, $ds, $type, $t['start'], $t['end']]);

            $isToday = ($ds === $now->format('Y-m-d'));
            if ($includeAttendance && !$isToday) {
                $present = (mt_rand(1, 100) <= 80);
                if ($present) {
                    $pdo->prepare("INSERT IGNORE INTO attendance (employee_id, attendance_date, check_in, check_out, status, gps_verified, face_verified) VALUES (?,?,?,?,'present',1,1)")
                        ->execute([$empId, $ds, $t['start'], $t['end']]);
                } else {
                    $pdo->prepare("INSERT IGNORE INTO attendance (employee_id, attendance_date, status) VALUES (?,?,'absent')")
                        ->execute([$empId, $ds]);
                }
            }
        }
    }
}

seed_week($pdo, $lastWeekStart, $employees, $types, true, $today);
seed_week($pdo, $thisWeekStart, $employees, $types, true, $today);

$summary = run_attendance_payroll_sync();
echo "Seeded roster + attendance for two weeks.\n";
echo "Payroll sync: {$summary['credited']} credited, {$summary['debited']} debited.\n";
