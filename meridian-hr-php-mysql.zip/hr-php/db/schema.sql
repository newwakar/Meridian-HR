-- ============================================================
-- Meridian HR — MySQL schema
-- Import with:  mysql -u root -p meridian_hr < db/schema.sql
-- ============================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS payroll_ledger;
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS attendance;
DROP TABLE IF EXISTS roster;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS employees;

-- ------------------------------------------------------------
-- employees: core HR record
-- ------------------------------------------------------------
CREATE TABLE employees (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  emp_code      VARCHAR(10) NOT NULL UNIQUE,      -- e.g. E01
  name          VARCHAR(120) NOT NULL,
  role_title    VARCHAR(120) NOT NULL,
  department    VARCHAR(80)  NOT NULL,
  base_salary   DECIMAL(10,2) NOT NULL DEFAULT 0,
  bonus         DECIMAL(10,2) NOT NULL DEFAULT 0,
  other_deduction DECIMAL(10,2) NOT NULL DEFAULT 0,
  color         VARCHAR(7) NOT NULL DEFAULT '#0F9D8C',
  is_active     TINYINT(1) NOT NULL DEFAULT 1,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- users: login accounts (separate from employee HR data)
-- ------------------------------------------------------------
CREATE TABLE users (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  employee_id   INT NULL,                          -- NULL for pure-admin accounts
  username      VARCHAR(60) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role          ENUM('admin','employee') NOT NULL DEFAULT 'employee',
  failed_attempts INT NOT NULL DEFAULT 0,
  locked_until  DATETIME NULL,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- roster: one scheduled shift per employee per date
-- ------------------------------------------------------------
CREATE TABLE roster (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  employee_id   INT NOT NULL,
  shift_date    DATE NOT NULL,
  shift_type    ENUM('morning','evening','night') NOT NULL,
  shift_start   TIME NOT NULL,
  shift_end     TIME NOT NULL,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_emp_date (employee_id, shift_date),
  FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- attendance: actual check-in / check-out per employee per date
-- ------------------------------------------------------------
CREATE TABLE attendance (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  employee_id   INT NOT NULL,
  attendance_date DATE NOT NULL,
  check_in      TIME NULL,
  check_out     TIME NULL,
  status        ENUM('present','absent','late') NOT NULL DEFAULT 'absent',
  gps_lat       DECIMAL(10,7) NULL,
  gps_lng       DECIMAL(10,7) NULL,
  gps_verified  TINYINT(1) NOT NULL DEFAULT 0,
  face_verified TINYINT(1) NOT NULL DEFAULT 0,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_emp_date (employee_id, attendance_date),
  FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- payroll_ledger: one +50 / -50 (or manual) entry per employee/date
-- ------------------------------------------------------------
CREATE TABLE payroll_ledger (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  employee_id   INT NOT NULL,
  entry_date    DATE NOT NULL,
  amount        DECIMAL(10,2) NOT NULL,
  reason        VARCHAR(160) NOT NULL,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_emp_date (employee_id, entry_date),
  FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- notifications
-- ------------------------------------------------------------
CREATE TABLE notifications (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  employee_id   INT NULL,                 -- NULL = broadcast to admins
  title         VARCHAR(160) NOT NULL,
  body          VARCHAR(255) NOT NULL,
  kind          ENUM('pos','neg','info') NOT NULL DEFAULT 'info',
  is_read       TINYINT(1) NOT NULL DEFAULT 0,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- Seed data
-- ============================================================

INSERT INTO employees (emp_code, name, role_title, department, base_salary, bonus, other_deduction, color) VALUES
('E01','Aisha Sharma','Software Engineer','Engineering',52000,1500,0,'#0F9D8C'),
('E02','Rahul Verma','Sales Executive','Sales',38000,0,600,'#E8604C'),
('E03','Priya Nair','HR Associate','Human Resources',41000,800,0,'#EFA93A'),
('E04','Karan Mehta','Support Specialist','Customer Support',32000,0,300,'#4A4FA0'),
('E05','Sneha Iyer','Marketing Specialist','Marketing',39000,1200,0,'#C2410C'),
('E06','Vikram Singh','Warehouse Associate','Operations',27000,0,0,'#0284C7'),
('E07','Ananya Das','Finance Analyst','Finance',45000,2000,0,'#7C3AED'),
('E08','Rohan Gupta','IT Support','IT',34000,500,400,'#059669');

-- Demo passwords (bcrypt hashes generated with PHP password_hash):
--   admin account   -> username: admin   password: Admin@123
--   employee accounts -> username: first name lowercase, password: Employee@123
-- Password hashes below are placeholders; the app's db/seed.php (re)generates
-- them correctly at install time so you never have to hand-edit a hash.
INSERT INTO users (employee_id, username, password_hash, role) VALUES
(NULL, 'admin', '$2y$10$placeholderplaceholderplaceholderplaceholderplaceh', 'admin'),
(1, 'aisha', '$2y$10$placeholderplaceholderplaceholderplaceholderplaceh', 'employee'),
(2, 'rahul', '$2y$10$placeholderplaceholderplaceholderplaceholderplaceh', 'employee'),
(3, 'priya', '$2y$10$placeholderplaceholderplaceholderplaceholderplaceh', 'employee'),
(4, 'karan', '$2y$10$placeholderplaceholderplaceholderplaceholderplaceh', 'employee'),
(5, 'sneha', '$2y$10$placeholderplaceholderplaceholderplaceholderplaceh', 'employee'),
(6, 'vikram', '$2y$10$placeholderplaceholderplaceholderplaceholderplaceh', 'employee'),
(7, 'ananya', '$2y$10$placeholderplaceholderplaceholderplaceholderplaceh', 'employee'),
(8, 'rohan', '$2y$10$placeholderplaceholderplaceholderplaceholderplaceh', 'employee');
