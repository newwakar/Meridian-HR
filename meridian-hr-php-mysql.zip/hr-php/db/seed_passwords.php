<?php
/**
 * Run this once, from the command line, right after importing schema.sql:
 *
 *   php db/seed_passwords.php
 *
 * It sets real bcrypt password hashes for the demo accounts so you don't
 * have to hand-compute them. Change the passwords below before using this
 * anywhere but a local/demo environment.
 */
require __DIR__ . '/../config.php';

$accounts = [
    'admin'  => 'Admin@123',
    'aisha'  => 'Employee@123',
    'rahul'  => 'Employee@123',
    'priya'  => 'Employee@123',
    'karan'  => 'Employee@123',
    'sneha'  => 'Employee@123',
    'vikram' => 'Employee@123',
    'ananya' => 'Employee@123',
    'rohan'  => 'Employee@123',
];

$pdo = db();
$stmt = $pdo->prepare("UPDATE users SET password_hash = ? WHERE username = ?");

foreach ($accounts as $username => $plainPassword) {
    $hash = password_hash($plainPassword, PASSWORD_DEFAULT);
    $stmt->execute([$hash, $username]);
    echo "Set password for '$username'\n";
}

echo "\nDone. Demo logins:\n";
echo "  admin / Admin@123        (Admin / HR Manager)\n";
echo "  aisha, rahul, priya, karan, sneha, vikram, ananya, rohan / Employee@123\n";
